python3 read-blockchain.py --ticker COMBEYS-bc640d # creates COMBEYS-bc640d.csv
sleep 12 # prevent timeouts to this IP
python3 read-blockchain.py --ticker COMBOTS-aa4150 # creates COMBOTS-aa4150.csv
python3 swap-cols.py --input COMBEYS-bc640d.csv
python3 swap-cols.py --input COMBOTS-aa4150.csv
python3 trim-combey-from-b.py --input COMBEYS-bc640d.csv
python3 trim-combot-from-b.py --input COMBOTS-aa4150.csv
python3 find-combey-ranks.py --input1 COMBEYS-bc640d.csv --input2 combeys.csv # creates combeys-ranks.csv
python3 find-combot-ranks.py --input1 COMBOTS-aa4150.csv --input2 combots.csv # creates combots-ranks.csv
python3 sort-by-col-a.py --input combeys-ranks.csv
python3 sort-by-col-a.py --input combots-ranks.csv
python3 hri-maths-combeys.py # hardwired input, WIP
python3 hri-maths-combots.py # hardwired input, WIP
